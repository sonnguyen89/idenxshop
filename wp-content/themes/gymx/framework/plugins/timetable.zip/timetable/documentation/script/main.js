
    $(document).ready(function() 
    {
        $('.tabs').tabs();
        
        jQuery.getScript('http://quanticalabs.com/.tools/EnvatoItems/js/getItems.js',function() { });
    });

